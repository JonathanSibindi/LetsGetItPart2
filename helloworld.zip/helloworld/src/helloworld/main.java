package helloworld;

import java.util.Arrays;
import java.util.Random;

public class main {
	public static void main(String args[]){
		int [][] b = new int[7][7];
		
		int k = 0;
		for(int j = 0; j < 7; j++){
			for(int i = 0; i < 7; i++){
				if(j < 2){
					if( i < 2){
						b[j][i] = 0;				
					}else if(i > 4){
						b[j][i] = 0;
					}else{
						b[j][i] = 2;
					}
				}
				else if(j > 4){
					if( i < 2){
						b[j][i] = 0;				
					}else if(i > 4){
						b[j][i] = 0;
					}else{
						b[j][i] = 2;
					}
				}else{

					b[j][i] = 2;
				}
			}
		}
		print(b);
		while(k < 10){
			Random random = new Random();
			int x = random.nextInt(7);
			int y = random.nextInt(7);
			boolean bin = false;
			if(x < 2){
				if( y < 2 || y > 4){
					bin = false;
				}else{
					bin = true;
				}
			}
			else if(x > 4){
				if( y < 2 || y >4){	
					bin = false;
				}else{
					bin = true;
				}
			}else{
				bin = true;
			}
			if(bin){
				b[x][y] = 1;
				k++;
			}
			
		}

		print(b);
	}
	
	private static void print(int[][] end) {
		// TODO Auto-generated method stub
		for(int i = 0; i < 7; i++) {
			for(int j = 0; j < 7; j++) {
				System.out.print(end[i][j]+" ");
			}
			System.out.println("");
		}
	}
}
